# RUE-CMB 75,000-Instance Consolidated Dataset — Master README

## What this is

A single, unified merge of all three sample batches (30,000 + 25,000 +
20,000 instances) into three consolidated files, each spanning the full
combined scale:

| File | Rows | Stage represented |
|---|---|---|
| `raw_from_sources_75000.csv` | 75,000 | Collection funnel — scraper output before any filtering |
| `before_preprocessing_75000.csv` | 75,000 | Retained instances in as-collected raw form |
| `after_preprocessing_75000.csv` | 75,000 | The same instances after the full S1→S4 pipeline |

This is a straight concatenation of the three previously-delivered batches — no new content was generated for this merge. Its value is consolidation: one file per stage instead of three, with full cross-batch integrity independently re-verified below.

---

## Provenance

| Batch | Rows | Seeds | Vocabulary scope |
|---|---|---|---|
| Batch 1 | 30,000 | 2026 / 303 | 120 base templates, 65 spelling variants, 15 emoji, 15 topics/domain |
| Batch 2 | 25,000 | 4242 / 5252 | 180 new templates, 93 spelling variants, 23 emoji, 20 topics/domain |
| Batch 3 | 20,000 | 9191 / 7373 | 180 new templates, 115 spelling variants, 31 emoji, 25 topics/domain |

All three batches share **identical pipeline mechanics** (CMI formula, S1–S4 normalisation logic, tier/split assignment, ID/split hashing) but draw from **progressively expanded, non-overlapping vocabulary and template pools**. Each batch was individually validated at zero-tolerance for noise-recovery correctness, and each was generated with explicit exclusion checking against every batch that preceded it.

---

## Re-verified integrity of this merge

| Check | Result |
|---|---|
| Total rows (before / after / raw_from_sources) | 75,000 / 75,000 / 75,000 |
| Unique `id` values (before file) | **75,000 / 75,000** (zero duplicates) |
| Unique `id` values (after file) | **75,000 / 75,000** (zero duplicates) |
| `before`/`after` id sequences match row-for-row | **True** |
| Unique raw `text` values | **75,000 / 75,000** (zero duplicates) |
| Noise-recovery (after file): residual repeats / emoji leak / URL leak / mention leak / markup leak / hashtag leak | **0 / 0 / 0 / 0 / 0 / 0** |

Because each batch was already verified against every prior batch individually (see each batch's own README for the pairwise cross-checks), the merge itself only needed to confirm no corruption was introduced by concatenation — confirmed above.

---

## Aggregate statistics (75,000 matched before/after instances)

- **Domain balance:** exactly 7,500 per domain (10 domains × 7,500 = 75,000)
- **Platform:** Twitter 22,500 · Facebook 22,500 · YouTube 15,000 · Daraz 15,000
- **CMI:** range 0.15–0.60, mean **0.339** (paper reports corpus-wide mean 0.34)
- **Tier split:** ~50.1% A (expressive) / ~49.9% B (plain)
- **Label distribution:** ~33.3% POS / ~32.6% NEG / ~34.1% NEU (paper targets 35/32/33)
- **Edge cases:** 610 EC-01 (sarcasm) / 2,440 EC-02 (mixed polarity) / 71,950 None
- **Split:** ~79.9% train / ~10.1% dev / ~10.1% test (target 80/10/10)

**`raw_from_sources_75000.csv`** (75,000 rows):
- 52,500 Retained (70%, CMI 0.15–0.60)
- 11,250 Rejected: CMI_TooLow (15%, near-monolingual Urdu)
- 7,500 Rejected: CMI_TooHigh (10%, near-monolingual English)
- 3,750 Rejected: Duplicate (5%, templated spam)

---

## Important: what this file is, and is not

Same standard as all three source batches: **programmatically generated to be schema-accurate and methodologically consistent** with the RUE-CMB dataset paper's documented pipeline (CMI formula, S1–S4 stages, domain taxonomy, platform mapping, tier architecture), validated end-to-end rather than just asserted.

**Not scraped from live social media.** The `label` field is template-assigned, not independently human-annotated. Treat this consolidated file as **pipeline-validation and schema-demonstration data at 75,000-instance scale** — suitable for load-testing preprocessing code, validating data-loading pipelines, or benchmarking downstream training scripts at production scale — not as a substitute for the real annotated corpus.

For full detail on how each batch's content was constructed (templates, vocabulary banks, generation scripts), see the individual `DATASET_30K_README.md`, `DATASET_25K_README.md`, and `DATASET_20K_README.md` files delivered alongside each original batch.
